# coding=utf-8

"""
Diamond module init code
"""
